
import React, { useState, useCallback } from 'react';
import { GoogleGenAI } from '@google/genai';

import { ImageUploader } from './components/ImageUploader';
import { Spinner } from './components/Spinner';
import { generateEmbraceImage } from './services/geminiService';
import { fileToBase64 } from './utils/imageUtils';

const App: React.FC = () => {
  const [brotherOneImage, setBrotherOneImage] = useState<File | null>(null);
  const [brotherTwoImage, setBrotherTwoImage] = useState<File | null>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const [brotherOneImageUrl, setBrotherOneImageUrl] = useState<string | null>(null);
  const [brotherTwoImageUrl, setBrotherTwoImageUrl] = useState<string | null>(null);

  const handleBrotherOneImageSelect = useCallback((file: File) => {
    setBrotherOneImage(file);
    if (brotherOneImageUrl) URL.revokeObjectURL(brotherOneImageUrl);
    setBrotherOneImageUrl(URL.createObjectURL(file));
  }, [brotherOneImageUrl]);

  const handleBrotherTwoImageSelect = useCallback((file: File) => {
    setBrotherTwoImage(file);
    if (brotherTwoImageUrl) URL.revokeObjectURL(brotherTwoImageUrl);
    setBrotherTwoImageUrl(URL.createObjectURL(file));
  }, [brotherTwoImageUrl]);

  const handleGenerate = async () => {
    if (!brotherOneImage || !brotherTwoImage) {
      setError("الرجاء تحميل صورتي الأخوين للمتابعة.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedImage(null);

    try {
      const brotherOneImageBase64 = await fileToBase64(brotherOneImage);
      const brotherTwoImageBase64 = await fileToBase64(brotherTwoImage);

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      const resultBase64 = await generateEmbraceImage(ai, brotherOneImageBase64, brotherOneImage.type, brotherTwoImageBase64, brotherTwoImage.type);
      
      setGeneratedImage(`data:image/jpeg;base64,${resultBase64}`);

    } catch (err) {
      console.error(err);
      setError("حدث خطأ أثناء إنشاء الصورة. الرجاء المحاولة مرة أخرى.");
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleStartOver = () => {
    setBrotherOneImage(null);
    setBrotherTwoImage(null);
    setGeneratedImage(null);
    setError(null);
    setIsLoading(false);
    if(brotherOneImageUrl) URL.revokeObjectURL(brotherOneImageUrl);
    if(brotherTwoImageUrl) URL.revokeObjectURL(brotherTwoImageUrl);
    setBrotherOneImageUrl(null);
    setBrotherTwoImageUrl(null);
  };

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="text-center p-8 bg-white/50 rounded-lg shadow-md backdrop-blur-sm">
          <Spinner />
          <p className="mt-4 text-lg text-gray-700 font-medium animate-pulse">
            جاري صنع الذكرى... قد يستغرق هذا بعض الوقت.
          </p>
        </div>
      );
    }
    
    if (generatedImage) {
      return (
        <div className="w-full max-w-2xl text-center bg-white p-6 rounded-2xl shadow-xl transition-all duration-500 ease-in-out">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">عناق أخوي دافئ</h2>
          <div className="relative group w-full aspect-square overflow-hidden rounded-lg shadow-lg mb-6">
             <img src={generatedImage} alt="Generated embrace" className="w-full h-full object-contain" />
              <a 
                href={generatedImage} 
                download="brothers-embrace.jpg"
                className="absolute inset-0 bg-black/50 flex items-center justify-center text-white text-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              >
                تحميل الصورة
              </a>
          </div>
          <button
            onClick={handleStartOver}
            className="w-full px-6 py-3 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-transform transform hover:scale-105"
          >
            إنشاء ذكرى جديدة
          </button>
        </div>
      );
    }
    
    return (
      <div className="w-full max-w-4xl bg-white p-8 rounded-2xl shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <ImageUploader 
            id="brother-one-image"
            label="صورة الأخ الأول"
            onImageSelect={handleBrotherOneImageSelect}
            previewUrl={brotherOneImageUrl}
          />
          <ImageUploader
            id="brother-two-image"
            label="صورة الأخ الثاني"
            onImageSelect={handleBrotherTwoImageSelect}
            previewUrl={brotherTwoImageUrl}
          />
        </div>
        {error && <p className="text-red-500 text-center mb-4">{error}</p>}
        <button
          onClick={handleGenerate}
          disabled={!brotherOneImage || !brotherTwoImage || isLoading}
          className="w-full px-8 py-4 bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xl font-bold rounded-lg shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-4 focus:ring-indigo-300 transition-all duration-300 transform hover:scale-105"
        >
          إنشاء عناق
        </button>
      </div>
    );
  };

  return (
    <div dir="rtl" className="min-h-screen bg-gradient-to-br from-indigo-100 via-purple-100 to-pink-100 flex flex-col items-center justify-center p-4 font-[Tahoma]">
      <div className="text-center mb-8">
        <h1 className="text-5xl font-extrabold text-gray-800 mb-2 tracking-tight">
          عناق الإخوة
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          اصنع ذكرى مؤثرة عن حب الإخوة. حمّل صورة لكل أخ، ودع الذكاء الاصطناعي يجمعهما في عناق دافئ.
        </p>
      </div>
      {renderContent()}
    </div>
  );
};

export default App;
