import { GoogleGenAI, Modality } from '@google/genai';

export const generateEmbraceImage = async (
  ai: GoogleGenAI,
  brotherOneImageBase64: string,
  brotherOneImageType: string,
  brotherTwoImageBase64: string,
  brotherTwoImageType: string,
): Promise<string> => {
  const prompt = `
    هاتان صورتان لأخوين.
    المهمة: قم بإنشاء صورة جديدة واقعية جداً يظهر فيها الأخوان وهما يتعانقان.
    تعليمات صارمة يجب اتباعها بدقة:
    1.  **الدقة القصوى في الوجوه**: هذه هي القاعدة الأهم. يجب نقل ملامح الوجه لكل أخ من صورته الأصلية إلى الصورة الجديدة بدقة متناهية. يجب أن يكون الشبه مطابقاً بنسبة 100% وتكون تفاصيل الوجه واضحة وحادة. لا تقم بأي تعديل أو تغيير أو تنعيم أو تطبيق فلاتر على الوجوه. حافظ على المظهر الواقعي والطبيعي تمامًا.
    2.  اتجاه الوجه: يجب أن يكون كلا الوجهين مواجهين للكاميرا بشكل واضح.
    3.  توحيد العمر: اجعل الأخوين يظهران في نفس المرحلة العمرية تقريبًا في الصورة النهائية، حتى لو كانت الصور الأصلية من فترات زمنية مختلفة.
    4.  عناق طبيعي: اجعل وضعية العناق تبدو طبيعية وعاطفية ودافئة، تظهر فيها رابطة الأخوة القوية.
    5.  خلفية فنية: اجعل الخلفية ضبابية بشكل خفيف (soft blur) لتركيز الانتباه على الأخوين، مع الحفاظ على وضوح تام في تفاصيل الأخوين نفسيهما (الوجوه، الملابس، الأجسام).
    6.  واقعية وجودة عالية: يجب أن تكون الصورة النهائية مؤثرة، واقعية جداً، وذات جودة فنية عالية.
  `;
  
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image-preview',
    contents: {
      parts: [
        {
          inlineData: {
            data: brotherOneImageBase64,
            mimeType: brotherOneImageType,
          },
        },
        {
          inlineData: {
            data: brotherTwoImageBase64,
            mimeType: brotherTwoImageType,
          },
        },
        {
          text: prompt,
        },
      ],
    },
    config: {
        responseModalities: [Modality.IMAGE, Modality.TEXT],
    },
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      return part.inlineData.data;
    }
  }

  throw new Error("لم يتم العثور على صورة في استجابة النموذج.");
};